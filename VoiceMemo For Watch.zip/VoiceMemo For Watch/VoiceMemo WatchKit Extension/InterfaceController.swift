//
//  InterfaceController.swift
//  VoiceMemo WatchKit Extension
//
//  Created by Tony on 15/12/21.
//  Copyright © 2015年 Tony. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    

    @IBOutlet var recBtn: WKInterfaceButton!
    
    @IBOutlet var playBtn: WKInterfaceButton!
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
    }

    override func willActivate() {
        super.willActivate()
    }

    override func didDeactivate() {
        super.didDeactivate()
    }
    
    func recFileURL() -> NSURL {
        let fileManager = NSFileManager.defaultManager()
        let container = fileManager.containerURLForSecurityApplicationGroupIdentifier("group.Parsons-the-newschool-for-design.VoiceMemo")
        // replace with your own identifier!!!!
        let audioFileURL = container!.URLByAppendingPathComponent("rec.mp4")
        
        return audioFileURL
    }
    
    
    // =========================================================================
    // MARK: - Actions
    
    @IBAction func recBtnTapped() {
        
        self.presentAudioRecorderControllerWithOutputURL(
            self.recFileURL(),
            preset: WKAudioRecorderPreset.HighQualityAudio,
            options: nil,
            completion:
            { (didSave, error) -> Void in
                print("didSave:\(didSave)\n")
        })
    }
    
    @IBAction func playBtnTapped() {
        
        self.presentMediaPlayerControllerWithURL(
            self.recFileURL(),
            options: nil) { (didPlayToEnd, endTime, error) -> Void in
        }
    }

}
